# Featured Collection Setup

This theme expects a collection metafield for the pinned products.

## Required metafield

- Owner: `Collection`
- Namespace and key: `custom.featured_products`
- Type: `List of products`

## How to use it

1. Open the target collection in Shopify admin.
2. Select exactly 15 products in `custom.featured_products`.
3. Keep collection page size at 20 products.
4. On the default collection view:
   - the 15 selected featured products render first
   - the next 5 slots are filled with normal collection products
5. On later infinite-scroll loads:
   - only non-featured products are appended
   - duplicate products are skipped
6. When sorting or filtering is applied:
   - featured pinning is disabled
   - Shopify default order is used
