class FeaturedCollectionController {
  constructor(container) {
    this.container = container;
    this.grid = container.querySelector('#product-grid');
    this.config = container.querySelector('[data-featured-collection-config]');
    this.status = container.querySelector('[data-featured-collection-status]');
    this.pagination = container.querySelector('.pagination-wrapper');
    this.loading = false;
    this.observer = null;

    if (!this.grid || !this.config) return;

    this.mode = this.config.dataset.mode || 'default';
    this.perPage = Number(this.config.dataset.perPage || 20);
    this.nextPage = Number(this.config.dataset.nextPage || 0);
    this.sectionId = this.config.dataset.sectionId || '';
    this.seenProductIds = new Set(
      Array.from(this.grid.querySelectorAll('[data-product-id]')).map((item) => item.dataset.productId)
    );
    this.featuredProductIds = new Set((this.config.dataset.featuredIds || '').split(',').filter(Boolean));

    if (this.pagination) this.pagination.style.display = 'none';

    if (this.nextPage > 0) {
      this.createObserver();
    } else {
      this.updateStatus('end');
    }
  }

  createObserver() {
    const sentinel = this.container.querySelector('[data-infinite-scroll-sentinel]');
    if (!sentinel) return;

    if (this.observer) this.observer.disconnect();

    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            this.loadMore();
          }
        });
      },
      {
        root: null,
        rootMargin: '400px 0px',
        threshold: 0
      }
    );

    this.observer.observe(sentinel);
  }

  buildRequestUrl(page) {
    const url = new URL(window.location.href);
    url.searchParams.delete('page');
    url.searchParams.delete('section_id');
    url.searchParams.set('page', page);
    url.searchParams.set('section_id', this.sectionId);
    return url.toString();
  }

  async loadMore() {
    if (this.loading || this.nextPage < 1 || !this.sectionId) return;

    this.loading = true;
    this.updateStatus('loading');

    let appendedCount = 0;

    try {
      while (this.nextPage > 0 && appendedCount < this.perPage) {
        const currentPage = this.nextPage;

        const response = await fetch(this.buildRequestUrl(currentPage), {
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });

        if (!response.ok) {
          throw new Error(`Request failed with status ${response.status}`);
        }

        const html = await response.text();
        const parsed = new DOMParser().parseFromString(html, 'text/html');
        const page = parsed.querySelector('[data-infinite-scroll-page]');

        if (!page) {
          this.nextPage = 0;
          break;
        }

        const items = Array.from(page.querySelectorAll('[data-product-id]'));

        items.forEach((item) => {
          const productId = item.dataset.productId;
          const isFeatured = this.featuredProductIds.has(productId);

          if (this.seenProductIds.has(productId)) return;
          if (this.mode === 'featured' && isFeatured) return;

          this.seenProductIds.add(productId);
          appendedCount += 1;

          if (item.classList.contains('scroll-trigger')) {
            item.classList.add('scroll-trigger--cancel');
          }

          this.grid.appendChild(item);
        });

        this.nextPage = Number(page.dataset.nextPage || 0);

        if (currentPage === this.nextPage) {
          this.nextPage = 0;
          break;
        }
      }

      this.updateStatus(this.nextPage > 0 ? 'idle' : 'end');
    } catch (error) {
      console.error('Infinite scroll failed', error);
      this.updateStatus('error');
    } finally {
      this.loading = false;
    }
  }

  updateStatus(state) {
    if (!this.status) return;

    const idle = this.status.querySelector('[data-status-idle]');
    const loading = this.status.querySelector('[data-status-loading]');
    const end = this.status.querySelector('[data-status-end]');
    const error = this.status.querySelector('[data-status-error]');

    [idle, loading, end, error].forEach((element) => {
      if (element) element.hidden = true;
    });

    if (state === 'loading' && loading) loading.hidden = false;
    if (state === 'end' && end) end.hidden = false;
    if (state === 'error' && error) error.hidden = false;
    if (state === 'idle' && idle) idle.hidden = false;
  }
}

window.initializeFeaturedCollection = function initializeFeaturedCollection(root = document) {
  const container = root.querySelector('#ProductGridContainer');
  if (!container) return;

  if (container.featuredCollectionController) return;

  container.featuredCollectionController = new FeaturedCollectionController(container);
};

document.addEventListener('DOMContentLoaded', () => {
  window.initializeFeaturedCollection();
});

document.addEventListener('shopify:section:load', () => {
  window.initializeFeaturedCollection();
});
